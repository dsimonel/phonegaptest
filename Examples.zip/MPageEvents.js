var MPageEventsExampleDeviceReady=function(){
document.addEventListener("searchbutton", mpeExtraEventsJSSearchButton, false);
document.addEventListener("menubutton", mpeExtraEventsJSMenuButton, false);
document.addEventListener("backbutton", mpeExtraEventsJSBackButton, false);
mpeEventsJSDeviceReady();
document.addEventListener("pause", mpeEventsJSPause, false);
document.addEventListener("resume", mpeEventsJSResume, false);
};
jQuery('#MPageEventsExample').bind('pageinit',function(event){
 if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MPageEventsExampleDeviceReady();
else
 document.addEventListener("deviceready", MPageEventsExampleDeviceReady, false);

});
function mpeExtraEventsJSSearchButton(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var d=new Date();
          var HTML=$('#lblOutput').html();
          var message="<br>Search button pressed at: "+d.toTimeString();
          $('#lblOutput').html(HTML+message);
        //end
        
}

function mpeExtraEventsJSMenuButton(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           var d=new Date();
          var HTML=$('#lblOutput').html();
          var message="<br>Menu Button pressed at: "+d.toTimeString();
          $('#lblOutput').html(HTML+message);
        //end
        
}

function mpeExtraEventsJSBackButton(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var d=new Date();
          var HTML=$('#lblOutput').html();
          var message="<br>Back button pressed at: "+d.toTimeString();
          $('#lblOutput').html(HTML+message);
        //end
        
}

function mpeEventsJSDeviceReady(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var d=new Date();
          var HTML=$('#lblOutput').html();
          var message="<br>The Device is ready at: "+d.toTimeString();
          $('#lblOutput').html(HTML+message);
        //end
        
}

function mpeEventsJSPause(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var d=new Date();
          var HTML=$('#lblOutput').html();
          var message="<br>The Application went to the sleep at: "+d.toTimeString();
          $('#lblOutput').html(HTML+message);
        //end
        
}

function mpeEventsJSResume(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var d=new Date();
          var HTML=$('#lblOutput').html();
          var message="<br>The Application awoke at: "+d.toTimeString();
          $('#lblOutput').html(HTML+message);
        //end
        
}

