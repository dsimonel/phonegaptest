jQuery('#MSliderExample').bind('pageinit',function(event){
 	jQuery('#mbUpdate').bind('click',function(event){jsWrapper(event,'mbUpdateSubmitEvent','mbUpdate_mbUpdateClick')});
	jQuery('#msBig').siblings('.ui-slider').bind('vmousedown',msBigJSDragStart);
	jQuery('#msBig').siblings('.ui-slider').bind('vmouseup',msBigJSDragOver);

});
        	function meMin_updatehidden(event)
            {
            	edit=$('#meMin').get(0);
                hidden=$('#meMin_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function meMax_updatehidden(event)
            {
            	edit=$('#meMax').get(0);
                hidden=$('#meMax_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function meValue_updatehidden(event)
            {
            	edit=$('#meValue').get(0);
                hidden=$('#meValue_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function msSmall_updatehidden(event)
            {
            	edit=$('#msSmall').get(0);
                hidden=$('#msSmall_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function msBig_updatehidden(event)
            {
            	edit=$('#msBig').get(0);
                hidden=$('#msBig_hidden').get(0);
                hidden.value=edit.value;
                            }
        function msBigJSDragOver(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var val=$('#msBig').val();
        $('#lblEnd').html("End drag value :"+val);
        //end
        
}

function msBigJSDragStart(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var val=$('#msBig').val();
        $('#lblStart').html("Start drag value :"+val);
        //end
        
}

