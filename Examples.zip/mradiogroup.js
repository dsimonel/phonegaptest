jQuery('#MRadioGroupExample').bind('pageinit',function(event){
 	jQuery('#mbtSubmit').bind('click',function(event){jsWrapper(event,'mbtSubmitSubmitEvent','mbtSubmit_mbtSubmitClick')});

});
