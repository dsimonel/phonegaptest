This is a basic example of mobile components.

All the pages that submit data with a MButton or have server-side events use a
regular POST method reloading the page. To use Ajax to update these pages, set
the "UseAjax" attribute to true. For more information, see
http://docwiki.embarcadero.com/HTML5_Builder/en/Mobile_AJAX

For the MList, you will need to setup a MySQL database. See
http://docwiki.embarcadero.com/HTML5_Builder/en/Sample_Applications