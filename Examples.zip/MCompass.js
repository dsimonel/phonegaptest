var MCompassExampleDeviceReady=function(){
  mcCompassActivate();
};
jQuery('#MCompassExample').bind('pageinit',function(event){
 if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MCompassExampleDeviceReady();
else
 document.addEventListener("deviceready", MCompassExampleDeviceReady, false);

});
var mcCompass=null;
function mcCompassJSChange(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //event's value when the Compass point North is undefined in Android
          event = event || 0;
          $('#lblDegrees').html(Math.round(event.magneticHeading)+"&deg;");
          $('#imgCompass').css({'-webkit-transform':'rotate(-'+event.magneticHeading+'deg)'});

        //end
        
}

var mcCompassActivate=function(options) {
   var options = options || {frequency:1};
   mcCompass=navigator.compass.watchHeading(mcCompassJSChange,function(){},options);
}
var mcCompassDeactivate=function() {
   navigator.compass.clearWatch(mcCompass);
   mcCompass=null;
}
