var MFilesExampleDeviceReady=function(){
 mfsMain=true;
  mfeMainActivate();
  mfReaderActivate();
  mdeDirectoryActivate();
  mfWriterActivate();
};
jQuery('#MFilesExample').bind('pageinit',function(event){
 	jQuery('#mbOpen').bind('click',mbOpenJSClick);
	jQuery('#mbSave').bind('click',mbSaveJSClick);
	jQuery('#mbRemove').bind('click',mbRemoveJSClick);
	jQuery('#mbCopy').bind('click',mbCopyJSClick);
	jQuery('#mbRename').bind('click',mbRenameJSClick);
if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MFilesExampleDeviceReady();
else
 document.addEventListener("deviceready", MFilesExampleDeviceReady, false);

});
        	function meTitle_updatehidden(event)
            {
            	edit=$('#meTitle').get(0);
                hidden=$('#meTitle_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function mtaText_updatehidden(event)
            {
            	edit=$('#mtaText').get(0);
                hidden=$('#mtaText_hidden').get(0);
                hidden.value=edit.value;
                            }
        function mbOpenJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js

        //if the user enters a path we'll resolve the file system. Otherwise well request a valid Filesystem
        var file=$('#meTitle').val();
        if(file.substring(0,1)=="/")
          mfsMainResolveLocalFileSystemURI("file://"+file);
        else
          mfsMainRequestFileSystem();
        //end
        
}

function mbSaveJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //once the save button is presswed we have to create a writer to write the contents on the file
          mfeMainCreateWriter();
        //end
        
}

function mbRemoveJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          mfeMainRemove();
        //end
        
}

        	function meNew_updatehidden(event)
            {
            	edit=$('#meNew').get(0);
                hidden=$('#meNew_hidden').get(0);
                hidden.value=edit.value;
                            }
        function mbCopyJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var name=$('#meNew').val();
        mfeMainCopyTo(mdeDirectory,name);
        //end
        
}

function mbRenameJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var name=$('#meNew').val();
        mfeMainMoveTo(mdeDirectory,name);
        //end
        
}

var mfsMain=null;
function mfsMainJSRequestFileSystemError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert('Error accessing the File System');
        //end
        
}

function mfsMainJSRequestFileSystem(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //if we can get a valid directory entry from the system, we asign it to our MDirectoryEntry Object to handle it
          mdeDirectory=event.root;
          var file=$('#meTitle').val();
          // We create a new file from the directory or open an existing one
          mdeDirectoryGetFile(file,{create:true});
        //end
        
}

function mfsMainJSResolveLocalFileSystemURIError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           alert(event.code);
        //end
        
}

function mfsMainJSResolveLocalFileSystemURI(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        //event holds the fileEntry object of the URI,
        // we assign it to our handler and call File to be able to read it.
        mfeMain=event;
        mfeMainFile();
        //end
        
}

var mfsMainResolveLocalFileSystemURI=function(URI) {
  var URI=URI || '';
  window.resolveLocalFileSystemURI(URI,mfsMainJSResolveLocalFileSystemURI,mfsMainJSResolveLocalFileSystemURIError);
}
var mfsMainRequestFileSystem=function(Type) {
  var Type=Type || LocalFileSystem.PERSISTENT;
  window.requestFileSystem(Type,0,mfsMainJSRequestFileSystem,mfsMainJSRequestFileSystemError);
}
var mfeMain=null;
function mfeMainJSGetMetadataError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           alert('error retrieving file Modification time');
        //end
        
}

function mfeMainJSGetMetadata(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //event holds metadata information, the only field provided is modificationTime
          var content=$('#lblFileInfo').html();
          content+="<br><b>Modified: </b>"+event.modificationTime;
          $('#lblFileInfo').html(content);
        //end
        
}

function mfeMainJSMoveToError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Error renaming the file');
        //end
        
}

function mfeMainJSMoveTo(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        $('#meNew').val('');
        //once the file is renamed we have to reload it
        //event holds the new file info, we need the name to reload it
        mdeDirectoryGetFile(event.name);
        //end
        
}

function mfeMainJSCopyToError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Error copying the file');
        //end
        
}

function mfeMainJSCopyTo(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        $('#meNew').val('');
        //once the file is copied we have to reload it
        //event holds the new file info, we need the name to reload it
        mdeDirectoryGetFile(event.name);

        //end
        
}

function mfeMainJSRemoveError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Eror removing the file');
        //end
        
}

function mfeMainJSRemove(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
            alert('file removed');
           $('#mtaText').val('');
           $('#mtaText').attr('disabled','disabled');
           $('#lblFileInfo').html('');
           $('#meTitle').val('');
        //end
        
}

function mfeMainJSGetParentError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Error retrieving parent information');
        //end
        
}

function mfeMainJSGetParent(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //event holds the file's parent information
          var content=$('#lblFileInfo').html();
          content+="<br><b>Parent Folder: </b>"+event.fullPath;
          $('#lblFileInfo').html(content);
        //end
        
}

var mfeMainGetMetadata=function() {
  if(mfeMain){
    mfeMain.getMetadata(mfeMainJSGetMetadata,mfeMainJSGetMetadataError);
  };
}
var mfeMainMoveTo=function(DirectoryEntry,Name) {
  if(mfeMain){
    var DirectoryEntry = DirectoryEntry || undefined;
    var Name = Name || '';
    mfeMain.moveTo(DirectoryEntry,Name,mfeMainJSMoveTo,mfeMainJSMoveToError);
  };
}
var mfeMainCopyTo=function(DirectoryEntry,Name) {
  if(mfeMain){
    var DirectoryEntry = DirectoryEntry || undefined;
    var Name = Name || '';
    mfeMain.copyTo(DirectoryEntry,Name,mfeMainJSCopyTo,mfeMainJSCopyToError);
  };
}
var mfeMainRemove=function() {
  if(mfeMain){
    mfeMain.remove(mfeMainJSRemove,mfeMainJSRemoveError);
  };
}
var mfeMainGetParent=function() {
  if(mfeMain){
    mfeMain.getParent(mfeMainJSGetParent,mfeMainJSGetParentError);
  };
}
function mfeMainJSFileError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Error getting the file');
        //end
        
}

function mfeMainJSFile(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        //event holds the file element provided by the fileEntry object
        //we can retireve file information and also pass it to our MFileReader to read its content
        var content="<b>File: </b>"+mfeMain.name;
        $('#lblFileInfo').html(content);

        mfeMainGetParent();
        mfeMainGetMetadata();
        // Our MFileReaderObject will read the file
        mfReader.readAsText(event);
        //end
        
}

function mfeMainJSCreateWriterError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Error creating a File Writer');
        //end
        
}

function mfeMainJSCreateWriter(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          // We assign the name of new new writer to our MFileWriter
         mfWriter.fileName=event.fileName;
         var text=$('#mtaText').val();
         //move the writer to the begining of the file
         mfWriter.position=0;
         mfWriter.write(text);
        //end
        
}

var mfeMainActivate=function(Filename) {
  var Filename=Filename || '';
  mfeMain=new FileEntry();
  mfeMain.fullPath=Filename;
}
var mfeMainFile=function() {
  if(mfeMain){
    mfeMain.file(mfeMainJSFile,mfeMainJSFileError);
  };
}
var mfeMainCreateWriter=function() {
  if(mfeMain){
    mfeMain.createWriter(mfeMainJSCreateWriter,mfeMainJSCreateWriterError);
  };
}
var mfReader=null;
function mfReaderJSAbort(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert('reading aborted');
        //end
        
}

function mfReaderJSError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('error reading the file');
        //end
        
}

function mfReaderJSLoadStart(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert('We are going to start to read the file');
        //end
        
}

function mfReaderJSLoadEnd(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('We are done with the file');
        //end
        
}

function mfReaderJSLoad(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        // file is loaded, event holds the file contents in target.result
        $('#mtaText').removeAttr('disabled');
        $('#mtaText').val(event.target.result);
        $('#meTitle').val('');
        //end
        
}

var mfReaderActivate=function() {
  mfReader=new FileReader();
  mfReader.onloadstart=mfReaderJSLoadStart;
  mfReader.onload=mfReaderJSLoad;
  mfReader.onabort=mfReaderJSAbort;
  mfReader.onerror=mfReaderJSError;
  mfReader.onloadend=mfReaderJSLoadEnd;
}
var mdeDirectory=null;
var mdeDirectoryGetMetadata=function() {
  if(mdeDirectory){
    mdeDirectory.getMetadata(function(){},function(){});
  };
}
var mdeDirectoryMoveTo=function(DirectoryEntry,Name) {
  if(mdeDirectory){
    var DirectoryEntry = DirectoryEntry || undefined;
    var Name = Name || '';
    mdeDirectory.moveTo(DirectoryEntry,Name,function(){},function(){});
  };
}
var mdeDirectoryCopyTo=function(DirectoryEntry,Name) {
  if(mdeDirectory){
    var DirectoryEntry = DirectoryEntry || undefined;
    var Name = Name || '';
    mdeDirectory.copyTo(DirectoryEntry,Name,function(){},function(){});
  };
}
var mdeDirectoryRemove=function() {
  if(mdeDirectory){
    mdeDirectory.remove(function(){},function(){});
  };
}
var mdeDirectoryGetParent=function() {
  if(mdeDirectory){
    mdeDirectory.getParent(function(){},function(){});
  };
}
function mdeDirectoryJSGetFile(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        // once we get the file we assign it to our MFileEntry Object to handle it
        mfeMain=event;
        // Our MFileReaderObject will read the file
        mfeMainFile();
        //end
        
}

function mdeDirectoryJSGetFileError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           alert('error Getting or creating the file');
        //end
        
}

var mdeDirectoryActivate=function(Directoryname) {
  var Directoryname=Directoryname || '';
  mdeDirectory=new DirectoryEntry();
  mdeDirectory.fullPath=Directoryname;
}
var mdeDirectoryGetDirectory=function(Filename,options) {
  if(mdeDirectory){
    var Filename = Filename || '';
    var options = options || {};
    mdeDirectory.getDirectory(Filename,options,function(){},function(){});
  };
}
var mdeDirectoryGetFile=function(Filename,options) {
  if(mdeDirectory){
    var Filename = Filename || '';
    var options = options || {};
    mdeDirectory.getFile(Filename,options,mdeDirectoryJSGetFile,mdeDirectoryJSGetFileError);
  };
}
var mdeDirectoryRemoveRecursively=function() {
  if(mdeDirectory){
    mdeDirectory.removeRecursively(function(){},function(){});
  };
}
var mfWriter=null;
function mfWriterJSAbort(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert("File writting it's been aborted");
        //end
        
}

function mfWriterJSError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        alert('error writing file');
        //end
        
}

function mfWriterJSWriteEnd(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert('We are done writting the file,');
        //end
        
}

function mfWriterJSWrite(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //file is been written, now we cna clean all fields
           alert('File succesfully written');
           $('#mtaText').val('');
           $('#mtaText').attr('disabled','disabled');
           $('#lblFileInfo').html('');
           $('#meTitle').val('');
        //end
        
}

function mfWriterJSWriteStart(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('We just started writting the file');
        //end
        
}

var mfWriterActivate=function() {
  mfWriter=new FileWriter();
  mfWriter.onwritestart=mfWriterJSWriteStart;
  mfWriter.onwrite=mfWriterJSWrite;
  mfWriter.onabort=mfWriterJSAbort;
  mfWriter.onerror=mfWriterJSError;
  mfWriter.onwriteend=mfWriterJSWriteEnd;
}
