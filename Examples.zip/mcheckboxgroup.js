jQuery('#MCheckBoxGroupExample').bind('pageinit',function(event){
 	jQuery('#mbtCheckSubmit').bind('click',function(event){jsWrapper(event,'mbtCheckSubmitSubmitEvent','mbtCheckSubmit_mbtCheckSubmitClick')});

});
