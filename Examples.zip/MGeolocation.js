var mpGeolocationTestDeviceReady=function(){
  mgGeolocatorActivate();
};
jQuery('#mpGeolocationTest').bind('pageinit',function(event){
 if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 mpGeolocationTestDeviceReady();
else
 document.addEventListener("deviceready", mpGeolocationTestDeviceReady, false);

});


         window.gmaps_mmap_callbacks = [];


         window.gmaps_mmap_loaded = function()
         {
            for(var i = 0; i < window.gmaps_mmap_callbacks.length; i++)
            {
               window.gmaps_mmap_callbacks[i]();
            }
         }

         window.gmaps_mmap_register_callback = function(callback)
         {
            if(!(callback in  window.gmaps_mmap_callbacks))
                window.gmaps_mmap_callbacks.push(callback);
         }

         // if google maps exists call load method
        if(window.google)
        {
            setTimeout(window.gmaps_mmap_loaded, 0);
        }
        else
        {
            var head= document.getElementsByTagName('head')[0];
           var script= document.createElement('script');
           script.type= 'text/javascript';
           script.src= "http://maps.google.com/maps/api/js?sensor=true&callback=gmaps_mmap_loaded";
           script.charset = "UTF-8";
           head.appendChild(script);
        }

               gmaps_mmap_register_callback(Map_load);
      function Map_load()
{
var Map_uiMap = jQuery("#Map").gmap({"zoom":5,"maxZoom":15,"minZoom":1,"draggable":true});
var Map_googleMap = jQuery(Map_uiMap.gmap('get', 'map'));
}

var mgGeolocator=null;
function mgGeolocatorJSChange(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
            var yourStartLatLng = new google.maps.LatLng(event.coords.latitude, event.coords.longitude);
            $('#Map').gmap({'center': yourStartLatLng});
        //end
        
}

function mgGeolocatorJSError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
             alert(event);
        //end
        
}

var mgGeolocatorActivate=function(options) {
   var options = options || {frequency:10,enableHighAccuracy:true,timeout:10000,maximumAge:10};
   mgGeolocator=navigator.geolocation.watchPosition(mgGeolocatorJSChange,mgGeolocatorJSError,options);
}
var mgGeolocatorDeactivate=function() {
   navigator.geolocation.clearWatch(mgGeolocator);
   mgGeolocator=null;
}
