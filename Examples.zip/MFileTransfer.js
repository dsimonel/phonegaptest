var MFileTransferExampleDeviceReady=function(){
 mftTransfer=true;
 mcCamera=true;
};
jQuery('#MFileTransferExample').bind('pageinit',function(event){
 	jQuery('#mbtUpload').bind('click',mbtUploadJSClick);
if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MFileTransferExampleDeviceReady();
else
 document.addEventListener("deviceready", MFileTransferExampleDeviceReady, false);

});
function mbtUploadJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var val=$("input[name='mrgOptions']:checked").val();
        if(val=='1')
          var Origin=navigator.camera.PictureSourceType.PHOTOLIBRARY;
        else
          var Origin=navigator.camera.PictureSourceType.CAMERA;

         mcCameraGetPicture({sourceType:Origin});
        //end
        
}

        	function meFilename_updatehidden(event)
            {
            	edit=$('#meFilename').get(0);
                hidden=$('#meFilename_hidden').get(0);
                hidden.value=edit.value;
                            }
        var mftTransfer=null;
function mftTransferJSUpload(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           $('#lblStatus').html(event.response);

        //end
        
}

function mftTransferJSUploadError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
               $('#lblStatus').html('error uploading the file');
        //end
        
}

var mftTransferUpload=function(File,URI,ExtraOptions) {
  if(mftTransfer){
    var URI=URI || 'http://192.168.0.157/upload.php';
    Options={fileKey:'uploadedfile',fileName:'image.jpg',mimeType:'image/jpeg',params:{}};
    var ExtraOptions = ExtraOptions || {}
    jQuery.extend(Options,ExtraOptions);
    mftTransfer=new FileTransfer();
    mftTransfer.upload(File,URI,mftTransferJSUpload,mftTransferJSUploadError,Options);
  }
}
var mcCamera=null;
function mcCameraJSSuccess(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var name=$('#meFilename').val();
          //event has the URI to the image file
          mftTransferUpload(event,'',{fileName:name});
        //end
        
}

function mcCameraJSError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
            $('#lblStatus').html(event);
        //end
        
}

mcCameraGetPicture=function(extraOptions) {
 if(mcCamera){
  var options = {quality:50,allowEdit:true,destinationType:navigator.camera.DestinationType.FILE_URI,sourceType:navigator.camera.PictureSourceType.CAMERA};
  var extraOptions=extraOptions || {};
  jQuery.extend(options,extraOptions);  navigator.camera.getPicture(mcCameraJSSuccess, mcCameraJSError,options);
 }
}
