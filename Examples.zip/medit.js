jQuery('#MEditExample').bind('pageinit',function(event){
 	jQuery('#meSearchBar').next('.ui-input-clear').bind('vmouseup',meSearchBarJSClearTextClick);

});
        	function meSearchBar_updatehidden(event)
            {
            	edit=$('#meSearchBar').get(0);
                hidden=$('#meSearchBar_hidden').get(0);
                hidden.value=edit.value;
                            }
        function meSearchBarJSClearTextClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert("The text is going to be Cleared");
        //end
        
}

        	function meRegularEdit_updatehidden(event)
            {
            	edit=$('#meRegularEdit').get(0);
                hidden=$('#meRegularEdit_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function MTextArea1_updatehidden(event)
            {
            	edit=$('#MTextArea1').get(0);
                hidden=$('#MTextArea1_hidden').get(0);
                hidden.value=edit.value;
                            }
        