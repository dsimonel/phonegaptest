jQuery('#MRadioButtonExample').bind('pageinit',function(event){
 	jQuery('#mrbButton2').bind('click',mrbButton1JSClick);
	jQuery('#mrbButton1').bind('click',mrbButton1JSClick);

});
function mrbButton1JSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert($(this).attr('id'));
        //end
        
}

