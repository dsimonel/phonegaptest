var MInfoExampleDeviceReady=function(){
  MConnection1Activate();
  MDevice1Activate();
  mdPhoneGapActivate();
  mdPlatformActivate();
  MDevice4Activate();
  mdVersionActivate();
};
jQuery('#MInfoExample').bind('pageinit',function(event){
 if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MInfoExampleDeviceReady();
else
 document.addEventListener("deviceready", MInfoExampleDeviceReady, false);

});
var MConnection1Activate=function() {
  if(MConnection1){
    var states={};
    states[Connection.UNKNOWN]='Unknown connection';
    states[Connection.ETHERNET]='Ethernet connection';
    states[Connection.WIFI]='WiFi connection';
    states[Connection.CELL_2G]='Cell 2G connection';
    states[Connection.CELL_3G]='Cell 3G connection';
    states[Connection.CELL_4G]='Cell 4G connection';
    states[Connection.NONE]='No network connection';
    var value=states[navigator.network.connection.type];
  jQuery('#MConnection1').html(value);
  }
}
var MDevice1Activate=function() {
  if(MDevice1){
    var value=device.name || 'Undefined';
  jQuery('#MDevice1').html(value);
  }
}
var mdPhoneGapActivate=function() {
  if(mdPhoneGap){
    var value=device.name || 'Undefined';
  jQuery('#mdPhoneGap').html(value);
  }
}
var mdPlatformActivate=function() {
  if(mdPlatform){
    var value=device.platform || 'Undefined';
  jQuery('#mdPlatform').html(value);
  }
}
var MDevice4Activate=function() {
  if(MDevice4){
    var value=device.uuid || 'Undefined';
  jQuery('#MDevice4').html(value);
  }
}
var mdVersionActivate=function() {
  if(mdVersion){
    var value=device.version || 'Undefined';
  jQuery('#mdVersion').html(value);
  }
}
