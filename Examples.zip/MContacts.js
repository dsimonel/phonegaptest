var MContactsExampleDeviceReady=function(){
 mcList=true;
 mcDelete=true;
};
jQuery('#MContactsExample').bind('pageinit',function(event){
 	jQuery('#mbGetContacts').bind('click',mbGetContactsJSClick);
	jQuery('#mbDelete').bind('click',mbDeleteJSClick);
	jQuery('#mbAdd').bind('click',mbAddJSClick);
if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MContactsExampleDeviceReady();
else
 document.addEventListener("deviceready", MContactsExampleDeviceReady, false);

});
function mbGetContactsJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          mcListList();
        //end
        
}

        	function meName_updatehidden(event)
            {
            	edit=$('#meName').get(0);
                hidden=$('#meName_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function mePhone_updatehidden(event)
            {
            	edit=$('#mePhone').get(0);
                hidden=$('#mePhone_hidden').get(0);
                hidden.value=edit.value;
                            }
        function mbDeleteJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var id=$("input[name='contacts']:checked").val();
          if(id)
          {
            mcDeleteList({filter:id});
          }
        //end
        
}

function mbAddJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var name=$('#meName').val();
        var phone= $('#mePhone').val();

        // we create a new contact
        var contact=navigator.contacts.create();

        contact.nickname=name;
        contact.displayName =name;

        // add a name property to our contact
        var namedata=new ContactName();
        namedata.givenName = name;

        contact.name=namedata;

        // add the phone number
        var phoneNumbers = [1];
        phoneNumbers[0] = new ContactField('home', phone, true);
        contact.phoneNumbers = phoneNumbers;

        // contact is ready let's save it
        mcListSave(contact);
        //end
        
}

var mcList=null;
function mcListJSList(event)
{

  var event = event || window.event;
  var params=null;
        //begin js

        var HTML="<fieldset data-role='controlgroup'>";
        // loop trough all contacts to display its data
        for(var x=0;x<event.length;x++){
            var nick="";
            var name="";
            var phone="";
            var id=event[x].id;
            if(event[x].nickname)
              var nick=event[x].nickname;
            if(event[x].name)
              var name=event[x].name.formatted;
            if(event[x].phoneNumbers)
            {
              for(var y=0;y<event[x].phoneNumbers.length;y++)
              {
                phone+="<i>"+ event[x].phoneNumbers[y].value+"</i> ";
              }
            }

            HTML+="<input name='contacts' type='radio' value='"+id+"' id='contact_"+id+"'><label for='contact_"+id+"'>"+nick+" "+name+" "+phone+"</label>";
        }

        //insert the data in the MPanel component
        $('#mrbHolder_outer').html(HTML+"</fieldset>");

        if(event.length>0)
        {
           $('#mbDelete').button('enable');
           $('#mrbHolder_outer').css('visibility','visible');
        }
        else
          $('#mbDelete').button('disable');

        // Recreate the page to enhance the contact's list
        $('#MContactsExample_page').trigger('create');

        //end
        
}

function mcListJSListError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
            alert('error '+event);
        //end
        
}

function mcListJSSave(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
            alert('contact saved');
         // After adding a new contact, list refreshed again
            mcListList();
        //end
        
}

function mcListJSSaveError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert('error saving contact');
        //end
        
}

mcListList=function(options,fields) {
 var options = options || {filter:'',multiple:true,updatedSince:''};
 var fields = fields || ["name","phoneNumbers"];
 if(mcList){
  navigator.contacts.find(fields, mcListJSList, mcListJSListError, options);
 }
}
mcListSave=function(contact) {
 if(mcList && contact){
   contact.save(mcListJSSave,mcListJSSaveError);
 }
}
mcListRemove=function(contact) {
 if(mcList && contact){
  contact.remove(function(){},function(){});
 }
}
var mcDelete=null;
function mcDeleteJSList(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          // Android is unable to find a contact by its ID.
          // So we have to get all IDs and find the one we want to delete.

            for(var x=0;x<event.length;x++){

                mcDeleteRemove(event[x]);

            }


        //end
        
}

function mcDeleteJSRemove(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Contact Removed');
         // After deletion, list refreshed again
         mcListList();
        //end
        
}

function mcDeleteJSRemoveError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           alert('Error Removing Contact');
        //end
        
}

mcDeleteList=function(options,fields) {
 var options = options || {filter:'',multiple:true,updatedSince:''};
 var fields = fields || ["id"];
 if(mcDelete){
  navigator.contacts.find(fields, mcDeleteJSList, function(){}, options);
 }
}
mcDeleteSave=function(contact) {
 if(mcDelete && contact){
   contact.save(function(){},function(){});
 }
}
mcDeleteRemove=function(contact) {
 if(mcDelete && contact){
  contact.remove(mcDeleteJSRemove,mcDeleteJSRemoveError);
 }
}
