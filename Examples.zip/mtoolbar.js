jQuery('#MToolBarExample').bind('pageinit',function(event){
 	jQuery('#mtbToolBar li').bind('click',mtbToolBarJSClick);

});
 var MToolBarExampleJSAjaxCallError=function(){
          jQuery("<div class='ui-loader ui-overlay-shadow ui-body-e ui-corner-all'><h1>"+ jQuery.mobile.pageLoadErrorMessage +"</h1></div>")
						.css({ "display": "block", "opacity": 0.96, "top": jQuery(window).scrollTop() + 100 })
						.appendTo( jQuery.mobile.pageContainer )
						.delay( 800 )
						.fadeOut( 400, function(){
							jQuery(this).remove();
						});
        };
 function mtbToolBarJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert($(this).find('a').text());
        //end
        
}

