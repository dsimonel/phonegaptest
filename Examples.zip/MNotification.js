var MNotificationExampleDeviceReady=function(){
 mnAlert=true;
 mnConfirm=true;
};
jQuery('#MNotificationExample').bind('pageinit',function(event){
 	jQuery('#mbPopConfirm').bind('click',mbPopConfirmJSClick);
if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MNotificationExampleDeviceReady();
else
 document.addEventListener("deviceready", MNotificationExampleDeviceReady, false);

});
function mbPopConfirmJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         mnConfirmNotification();
        //end
        
}

var mnAlert=null;
var mnAlertNotification=function() {
  if(mnAlert){
    navigator.notification.alert('This is your Alert message',function(){},'Custom Alert Message','Close');
  }
}
var mnConfirm=null;
function mnConfirmJSCloseNotification(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         if(event==1)
          mnAlertNotification();
        //end
        
}

var mnConfirmNotification=function() {
  if(mnConfirm){
    navigator.notification.confirm('Do you want to open an Alert Message?',mnConfirmJSCloseNotification,'Open Alert','yes,no');
  }
}
