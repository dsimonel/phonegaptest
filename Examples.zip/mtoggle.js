jQuery('#MToggleExample').bind('pageinit',function(event){
 	jQuery('#mbtValues').bind('click',function(event){jsWrapper(event,'mbtValuesSubmitEvent','mbtValues_mbtValuesClick')});

});
