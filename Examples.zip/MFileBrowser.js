var MFileBrowserDeviceReady=function(){
 mfsMain=true;
  mdDirectoryActivate();
 mdrReader=true;
MPageEventsJSDeviceReady();
};
jQuery('#MFileBrowser').bind('pageinit',function(event){
 	jQuery('#mbCreateFile').bind('click',mbCreateFileJSClick);
	jQuery('#mbCreateDirectory').bind('click',mbCreateDirectoryJSClick);
	jQuery('#mbDelete').bind('click',mbDeleteJSClick);
	jQuery('#mbMove').bind('click',mbMoveJSClick);
	jQuery('#mbCopy').bind('click',mbCopyJSClick);
if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MFileBrowserDeviceReady();
else
 document.addEventListener("deviceready", MFileBrowserDeviceReady, false);

});
function mbCreateFileJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var name=$('#meFile').val();
          if(name!="")
          {
            //getFile either creates or opens a file
            mdDirectoryGetFile(name,{create:true});
          }
        //end
        
}

        	function meFile_updatehidden(event)
            {
            	edit=$('#meFile').get(0);
                hidden=$('#meFile_hidden').get(0);
                hidden.value=edit.value;
                            }
                	function meDirectory_updatehidden(event)
            {
            	edit=$('#meDirectory').get(0);
                hidden=$('#meDirectory_hidden').get(0);
                hidden.value=edit.value;
                            }
        function mbCreateDirectoryJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          var name=$('#meDirectory').val();
          if(name!="")
          {
            //getDirectory either creates or returns a directory
            mdDirectoryGetDirectory(name,{create:true});
          }
        //end
        
}

function mbDeleteJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          if($('#mcbAll').attr('checked'))
            mdDirectoryRemoveRecursively();
          else
            mdDirectoryRemove();
        //end
        
}

        	function meMove_updatehidden(event)
            {
            	edit=$('#meMove').get(0);
                hidden=$('#meMove_hidden').get(0);
                hidden.value=edit.value;
                            }
        function mbMoveJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        // We need a full path to copy or move the directory
        // once we have the path we have to break it down in path and directory name
        var location=$('#meMove').val();
        var position=location.lastIndexOf('/');
        var name=location.substring(position+1);
        var path=location.substring(0,position);

        //moveTo needs a DirectoryEntry and a directory Name.
        // we create a new directoryEntry and assigh our path as fullPath
        var parent=new DirectoryEntry();
        parent.fullPath=path;
        mdDirectoryMoveTo(parent,name);
        //end
        
}

function mbCopyJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        // We need a full path to copy or move the directory
        // once we have the path we have to break it down in path and directory name
        var location=$('#meMove').val();
        var position=location.lastIndexOf('/');
        var name=location.substring(position+1);
        var path=location.substring(0,position);

        //moveTo needs a DirectoryEntry and a directory Name.
        // we create a new directoryEntry and assigh our path as fullPath
        var parent=new DirectoryEntry();
        parent.fullPath=path;
        mdDirectoryCopyTo(parent,name);
        //end
        
}

var mfsMain=null;
function mfsMainJSRequestFileSystemError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           alert('Error requesting the file system: '+event);
        //end
        
}

function mfsMainJSRequestFileSystem(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        // once the file system is succesfully retrieved, it is stored in event.
        // we assign event.root to our MDirectoryEntry object, so we can manipulate the directory
         mdDirectory=event.root;
         mdrReader=mdDirectory.createReader();

         // we empty the MList component
         $('#mlDirectories').empty();

         // tel our directory reader to get all the directory entries
         mdrReaderReadEntries();
        //end
        
}

var mfsMainResolveLocalFileSystemURI=function(URI) {
  var URI=URI || '';
  window.resolveLocalFileSystemURI(URI,function(){},function(){});
}
var mfsMainRequestFileSystem=function(Type) {
  var Type=Type || LocalFileSystem.PERSISTENT;
  window.requestFileSystem(Type,0,mfsMainJSRequestFileSystem,mfsMainJSRequestFileSystemError);
}
var mdDirectory=null;
function mdDirectoryJSGetMetadataError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert("Error retrieving directory's metadata");
        //end
        
}

function mdDirectoryJSGetMetadata(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //event holds metadata information, the only field provided is modificationTime
          var content =$('#lblInfo').html();
          content+="<br><b>Modified: </b>"+event.modificationTime;
          $('#lblInfo').html(content);
        //end
        
}

function mdDirectoryJSMoveToError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('error moving the directory '+event.error);
        //end
        
}

function mdDirectoryJSMoveTo(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         mdDirectoryGetDirectory(event.fullPath);
        //end
        
}

function mdDirectoryJSCopyToError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Error copying the directory');
        //end
        
}

function mdDirectoryJSCopyTo(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        //event is a directoryEntry object, we need its fullPath to refresh our list
         mdDirectoryGetDirectory(event.fullPath);
        //end
        
}

function mdDirectoryJSRemoveError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('Directory not empty');
        //end
        
}

function mdDirectoryJSRemove(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        //if we succesfully delete a directory we have to move to the parent directory
         mdDirectoryGetParent();
         alert('Directory Deleted');
        //end
        
}

function mdDirectoryJSGetDirectoryError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert("Directory does no exists");
        //end
        
}

function mdDirectoryJSGetDirectory(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        //event has a DirectoryEntry object.
        // If both paths are the same we haven't moved our position
        if(mdDirectory.fullPath==event.fullPath)
        {
          alert("Can't get to that directory");
        }
        else
        {
          //assignt the DirectoryEntry Object to our handler
          mdDirectory=event;

          //assign a new reader to our DirectoryReader handler
          mdrReader=mdDirectory.createReader();

          //read the contents of the directory
          mdrReaderReadEntries();
        }
        //end
        
}

var mdDirectoryGetMetadata=function() {
  if(mdDirectory){
    mdDirectory.getMetadata(mdDirectoryJSGetMetadata,mdDirectoryJSGetMetadataError);
  };
}
var mdDirectoryMoveTo=function(DirectoryEntry,Name) {
  if(mdDirectory){
    var DirectoryEntry = DirectoryEntry || undefined;
    var Name = Name || '';
    mdDirectory.moveTo(DirectoryEntry,Name,mdDirectoryJSMoveTo,mdDirectoryJSMoveToError);
  };
}
var mdDirectoryCopyTo=function(DirectoryEntry,Name) {
  if(mdDirectory){
    var DirectoryEntry = DirectoryEntry || undefined;
    var Name = Name || '';
    mdDirectory.copyTo(DirectoryEntry,Name,mdDirectoryJSCopyTo,mdDirectoryJSCopyToError);
  };
}
var mdDirectoryRemove=function() {
  if(mdDirectory){
    mdDirectory.remove(mdDirectoryJSRemove,mdDirectoryJSRemoveError);
  };
}
var mdDirectoryGetParent=function() {
  if(mdDirectory){
    mdDirectory.getParent(mdDirectoryJSGetDirectory,mdDirectoryJSGetDirectoryError);
  };
}
function mdDirectoryJSGetFile(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          // after getting a file we have to refresh the list
          mdrReaderReadEntries();
        //end
        
}

function mdDirectoryJSGetFileError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert('error creatring file');
        //end
        
}

function mdDirectoryJSRemoveRecursivelyError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         alert("Error removing the directory and it's contents");
        //end
        
}

var mdDirectoryActivate=function(Directoryname) {
  var Directoryname=Directoryname || '';
  mdDirectory=new DirectoryEntry();
  mdDirectory.fullPath=Directoryname;
}
var mdDirectoryGetDirectory=function(Filename,options) {
  if(mdDirectory){
    var Filename = Filename || '';
    var options = options || {};
    mdDirectory.getDirectory(Filename,options,mdDirectoryJSGetDirectory,mdDirectoryJSGetDirectoryError);
  };
}
var mdDirectoryGetFile=function(Filename,options) {
  if(mdDirectory){
    var Filename = Filename || '';
    var options = options || {};
    mdDirectory.getFile(Filename,options,mdDirectoryJSGetFile,mdDirectoryJSGetFileError);
  };
}
var mdDirectoryRemoveRecursively=function() {
  if(mdDirectory){
    mdDirectory.removeRecursively(mdDirectoryJSRemove,mdDirectoryJSRemoveRecursivelyError);
  };
}
var mdrReader=null;
function mdrReaderJSReadEntries(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          //let's clean everything, the directories list and the info label
          $('#mlDirectories').empty();
          var content="<b>Directory: </b>"+mdDirectory.fullPath;
          $('#lblInfo').html(content);

          // we'll assign to the move edit field the path so it is easy to write new directory names to move or copy them
          $('#meMove').val(mdDirectory.fullPath);

          //get the metadata information of the directory
          mdDirectoryGetMetadata();

          //First we include a link to the parent directory
          var content ="<li data-icon='back'><a href='..' rel='external' class='directory'  > .. </a></li>";

          // go trough all the elements and include them
          for(var x=0;x<event.length;x++)
          {
            content+="<li>";
            if(event[x].isDirectory)
              content+="<a href='"+event[x].name+"' rel='external' class='directory' >";
            content+=event[x].name;
            if(event[x].isDirectory)
              content+="</a>";
            content+="</li>";
          }
          $('#mlDirectories').append(content);

          $('#mlDirectories').listview('refresh');
        //end
        
}

function mdrReaderJSReadEntriesError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          alert("Error reading the directory content");
        //end
        
}

var mdrReaderReadEntries=function() {
  if(mdrReader){
    mdrReader.readEntries(mdrReaderJSReadEntries,mdrReaderJSReadEntriesError);
  };
}
function MPageEventsJSDeviceReady(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        // once the device is ready we request the main file system
         mfsMainRequestFileSystem();

         //this is the event that will trigger all the directory elements in the list to change directory
          $('.directory').live('click',function(event){
          var directory=$(this).attr('href');
          if(directory=="..")
          {
            mdDirectoryGetParent();
          }
          else
          {
            mdDirectoryGetDirectory(directory);
          }

          return false;
         });
        //end
        
}

