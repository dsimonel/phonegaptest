var MStorageExampleDeviceReady=function(){
  MDBUsersActivate();
 MDBTCreateTable=true;
 MDBTListUsers=true;
 MDBTAddUser=true;
 MDBDeleteUser=true;
mpeMobileEventsJSDeviceReady();
};
jQuery('#MStorageExample').bind('pageinit',function(event){
 	jQuery('#mbAdd').bind('click',mbAddJSClick);
	jQuery('#mbtList').bind('click',mbtListJSClick);
	jQuery('#mbtDelete').bind('click',mbtDeleteJSClick);
if(typeof PhoneGap !== 'undefined' && PhoneGap.available)
 MStorageExampleDeviceReady();
else
 document.addEventListener("deviceready", MStorageExampleDeviceReady, false);

});
        	function meName_updatehidden(event)
            {
            	edit=$('#meName').get(0);
                hidden=$('#meName_hidden').get(0);
                hidden.value=edit.value;
                            }
        function mbAddJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         MDBTAddUserTransaction();
        //end
        
}

function mbtListJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        MDBTListUsersTransaction();
        //end
        
}

function mbtDeleteJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         MDBDeleteUserTransaction();
        //end
        
}

var MDBUsers=null;
var MDBUsersActivate=function(DBName,DBVersion,DBDisplayName,DBSize) {
   var DBName = DBName || 'users';
   var DBVersion = DBVersion || '1';
   var DBDisplayName = DBDisplayName || 'Users Database';
   var DBSize = DBSize || '10000';
  MDBUsers=window.openDatabase(DBName,DBVersion,DBDisplayName,DBSize);
}
var MDBTCreateTable=null;
function MDBTCreateTableJSTransaction(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
         event.executeSql('CREATE TABLE IF NOT EXISTS USERS (id INTEGER PRIMARY KEY AUTOINCREMENT, name)');
        //end
        
}

function MDBTCreateTableJSTransactionsuccess(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
          $('#lblDBStatus').html('DB Status: <b>ready</b>');
        //end
        
}

function MDBTCreateTableJSTransactionError(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           alert('Error on SQL :'+event.message);
           $('#lblDBStatus').html('DB Status: <b>NOT ready</b>');
        //end
        
}

var MDBTCreateTableTransaction=function() {
  if(MDBTCreateTable && MDBUsers){
    MDBUsers.transaction(MDBTCreateTableJSTransaction,MDBTCreateTableJSTransactionError,MDBTCreateTableJSTransactionsuccess);
  }
}
function mpeMobileEventsJSDeviceReady(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        MDBTCreateTableTransaction();
        //end
        
}

var MDBTListUsers=null;
function MDBTListUsersJSTransaction(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
           event.executeSql('SELECT * FROM USERS',[],function(x,items){
            var HTML ="";
            if(items.rows.length==0)
            {
              HTML="No Users found";
              $('#mbtDelete').button('disable');
            }
            else
            {
              $('#mbtDelete').button('enable');
              HTML+="<fieldset data-role='controlgroup'>";
              for(var x=0;x<items.rows.length;x++)
              {
                 var name=items.rows.item(x).name;
                 var id=items.rows.item(x).id;
                 HTML+="<input name='users' type='radio' value='"+id+"' id='usuario_"+id+"'><label for='usuario_"+id+"'>"+name+"</label>";

              }
              HTML+="</fieldset>";
            }
            $('#lblOutput').html(HTML);

            // recreate the page to enhance the list
            $('#MStorageExample_page').trigger( "create" );

           },MDBTCreateTableJSTransactionError);
        //end
        
}

var MDBTListUsersTransaction=function() {
  if(MDBTListUsers && MDBUsers){
    MDBUsers.transaction(MDBTListUsersJSTransaction,MDBTCreateTableJSTransactionError,function(){});
  }
}
var MDBTAddUser=null;
function MDBTAddUserJSTransaction(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var name=$('#meName').val();
        if(name!="")
          event.executeSql("INSERT INTO USERS(name) VALUES('"+name+"')");
        //end
        
}

function MDBTAddUserJSTransactionsuccess(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        $('#meName').val('');
        MDBTListUsersTransaction();
        //end
        
}

var MDBTAddUserTransaction=function() {
  if(MDBTAddUser && MDBUsers){
    MDBUsers.transaction(MDBTAddUserJSTransaction,MDBTCreateTableJSTransactionError,MDBTAddUserJSTransactionsuccess);
  }
}
var MDBDeleteUser=null;
function MDBDeleteUserJSTransaction(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        var id=$("input[name='users']:checked").val();
        if(id)
          event.executeSql("DELETE FROM USERS WHERE id='"+id+"' ");
        //end
        
}

function MDBDeleteUserJSTransactionsuccess(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        MDBTListUsersTransaction();
        //end
        
}

var MDBDeleteUserTransaction=function() {
  if(MDBDeleteUser && MDBUsers){
    MDBUsers.transaction(MDBDeleteUserJSTransaction,MDBTCreateTableJSTransactionError,MDBDeleteUserJSTransactionsuccess);
  }
}
